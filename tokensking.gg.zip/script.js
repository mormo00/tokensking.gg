// Al momento non c'è script, ma potremo aggiungere funzioni come copia token, animazioni ecc.
console.log("TokensKing.gg loaded");
