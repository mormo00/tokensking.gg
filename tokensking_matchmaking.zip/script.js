function login() {
  const username = document.getElementById("username").value;
  if (username.trim() === "") {
    alert("Inserisci un nome utente valido.");
    return;
  }
  document.getElementById("user").textContent = username;
  document.querySelector(".auth").style.display = "none";
  document.getElementById("dashboard").style.display = "block";
}

function joinMatch() {
  const players = ["PlayerX", "PlayerY", "PlayerZ", "Ghost42", "Sweat99"];
  const randomPlayer = players[Math.floor(Math.random() * players.length)];
  document.getElementById("match-result").textContent =
    "Hai trovato una partita contro: " + randomPlayer + "!";
}
